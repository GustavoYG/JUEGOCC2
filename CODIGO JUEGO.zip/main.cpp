#include <SFML/Graphics.hpp>
#include <memory>
#include <vector>
#include <iostream>
#include "Tank.h"
#include "TankFactory.h"
#include "Bullet.h"
#include "Mine.h"


#include "menu.h"

int main() {
    Menu menu;
    menu.showMenu();

    return 0;
}
